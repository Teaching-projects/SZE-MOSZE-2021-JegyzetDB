<?php return [
    'plugin' => [
        'name' => 'Jegyzet',
        'description' => ''
    ]
];